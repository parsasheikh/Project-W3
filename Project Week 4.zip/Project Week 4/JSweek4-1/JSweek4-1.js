let userPhraise = prompt("Please enter your your cotent").split('');
let listOfWords = ["a" , "e" , "i" , "o" , "u"];

function removeChar(arr , words) {

    for (let i = 0; i < words.length; i++) {

        arr = arr.filter((phraise) => phraise.toLowerCase() !== words[i] );
    }

    return(arr.join(""));
}

console.log(removeChar(userPhraise , listOfWords));