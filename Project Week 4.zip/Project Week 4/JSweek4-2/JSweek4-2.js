const namesByUser = prompt("please enter names and put comma ( , ) between them.");
const arrayOfNames = namesByUser.split(",");

function likes(arrOfStr) {
    if (!namesByUser) {
        
        console.log("Nobody likes this.");

    }else if(arrOfStr.length < 3){
        
        switch (arrOfStr.length) {
            case 'value1':
                console.log(`${arrOfStr[0]} likes this.`);
                break;

            default:
                console.log(`${arrOfStr[0]} and ${arrOfStr[1]} likes this.`);
                break;        
        }
    }else {
        
        let names = "";

        for (let i = 0; i < arrOfStr.length-1; i++) {
            names = names + arrOfStr[i] + " , ";
        }
        names.slice(0 , -2);

        console.log(`${names}and ${arrOfStr[arrOfStr.length-1]} likes this.`);
    }
    
}

likes(arrayOfNames);