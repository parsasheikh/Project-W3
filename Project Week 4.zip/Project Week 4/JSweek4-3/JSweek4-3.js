const NumByUser1 = prompt("please enter your first array , and seperate items with comma").split(",");
const NumByUser2 = prompt("please enter your second array , and seperate items with comma").split(",");


function notSameNums(array1, array2) {
    
    let input1 = [...array1];

    for (let i = 0; i < array2.length; i++) {
       input1 = input1.filter((item) => item !== array2[i]);
    }
    
    let input2 = [...array2];

    for (let i = 0; i < array1.length; i++) {
        input2 = input2.filter((item) => item !== array1[i]);
    }

    const sum = [...input1 , ...input2];
    return sum;
}

console.log(notSameNums(NumByUser1 , NumByUser2));